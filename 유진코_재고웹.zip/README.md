# 유진코 재고현황 — Cloudflare Workers 배포 안내

`yujinstock.workers.dev` 는 계정의 **workers.dev 서브도메인**입니다.
Worker 를 배포하면 최종 주소는 자동으로 **`https://<Worker이름>.yujinstock.workers.dev`** 가 됩니다.
이 패키지의 Worker 이름은 `yujinco-stock` 이므로 → **https://yujinco-stock.yujinstock.workers.dev**

---

## 0. 준비물

- Node.js 20 이상 (PC)
- Cloudflare 계정 (Account ID: `4c94f8f3b01b2272b8e8b76978b937f7` — `wrangler.toml` 에 이미 입력됨)
- 이 폴더 그대로 사용 (파일명·구조 변경 금지)

```
.
├─ wrangler.toml          ← Worker 설정 (이름·계정·KV 바인딩)
├─ package.json
├─ src/
│  ├─ worker.js           ← 서버 (읽기 API / 업로드 API / 화면 연결)
│  └─ seed.mjs            ← 배포 시점 재고 2,070행 (KV 가 비었을 때만 사용)
└─ public/                ← 화면 (정적 자산)
   ├─ index.html          ← 재고현황 뷰어 (읽기 전용·로그인 없음)
   ├─ admin.html          ← 업로드 화면 (관리자 키 필요)
   ├─ sw.js               ← 서비스워커 (홈화면 바로가기 자동 갱신)
   ├─ manifest.json
   ├─ _headers / _redirects
   └─ icons/icon-192.png, icon-512.png
```

---

## 1. 로그인

터미널(맥: 터미널 / 윈도우: PowerShell)에서 이 폴더로 이동한 뒤:

```bash
cd 이폴더경로
npx wrangler login
```

브라우저가 열리면 Cloudflare 계정으로 **Allow** 클릭.

---

## 2. KV 저장소 만들기 (재고가 저장되는 곳)

```bash
npx wrangler kv namespace create INV
```

출력 예시:

```
[[kv_namespaces]]
binding = "INV"
id = "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6"
```

👉 나온 **id 값**을 `wrangler.toml` 의 `REPLACE_WITH_KV_NAMESPACE_ID` 자리에 붙여넣기:

```toml
[[kv_namespaces]]
binding = "INV"
id = "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6"
```

> 무료 플랜에서도 KV 1개면 충분합니다. 재고 2,070행이 약 0.2MB, KV 무료 한도는 1GB.

---

## 3. 관리자 키(시크릿) 등록

```bash
npx wrangler secret put ADMIN_KEY
```

`Enter a secret value:` 가 나오면 **7887** 입력 후 Enter.
(원하는 값으로 바꿔도 됩니다. 이 값이 업로드 비밀번호입니다. 코드에는 저장되지 않습니다.)

---

## 4. 배포

```bash
npx wrangler deploy
```

성공하면 아래처럼 주소가 출력됩니다:

```
Deployed yujinco-stock triggers
  https://yujinco-stock.yujinstock.workers.dev
```

이 주소가 **공유용 주소**입니다. 로그인 없이 누구나 열립니다.
업로드 화면은 **https://yujinco-stock.yujinstock.workers.dev/admin**

---

## 5. 배포 확인 (3개만 보면 됩니다)

| 주소 | 정상일 때 |
|---|---|
| `/` | 재고 목록이 뜨고 상단에 `자동 업데이트 · 2026-10-28 23:56 기준` |
| `/api/inventory` | `{"source":"seed","count":2070,...}` |
| `/health` | `{"ok":true,"kv":true,"secret":true}` |

`kv:false` 면 2단계(KV id)가 빠진 것, `secret:false` 면 3단계(시크릿)가 빠진 것입니다.

---

## 6. 매일 쓰는 법

1. `/admin` 접속 → 관리자 키 입력 (체크하면 이 브라우저에 저장)
2. `쇼핑몰재고현황` 시트가 있는 엑셀 선택
3. **서버에 올리고 모두에게 공개** 클릭
4. 끝 — 뷰어는 60초 안에 자동 반영, 화면 하단에 "새 재고가 올라왔습니다" 표시

- 반영 항목: 품목코드 · 품목명 · 재고수량 · 재고단가 · 재고금액 · 품목그룹
- **김해재고 시트는 읽지 않습니다** (기존과 동일)
- 업로드 한도 5MB / 20,000행

---

## 7. 홈 화면 바로가기 (보는 사람용)

- **아이폰** Safari → 공유 → `홈 화면에 추가`
- **안드로이드** Chrome → ⋮ → `홈 화면에 추가`

한 번 추가하면 이후에는 내가 올릴 때마다 자동으로 최신 재고가 보입니다.
(서비스워커 network-first + `skipWaiting`/`clients.claim`, 캐시 버전 `2026-11-11-cf1`)

---

## 8. 나중에 고칠 때

| 하고 싶은 것 | 방법 |
|---|---|
| 관리자 키 변경 | `npx wrangler secret put ADMIN_KEY` 다시 실행 |
| 화면 문구·디자인 수정 | `public/index.html` 수정 → `npx wrangler deploy` |
| 재고 초기값(seed) 교체 | `src/seed.mjs` 교체 → `npx wrangler deploy` |
| 커스텀 도메인 (`stock.nasashop.co.kr`) | Cloudflare 대시보드 → Workers → yujinco-stock → Settings → Domains & Routes → Add custom domain |

---

## 참고 — 로컬 미리보기

```bash
npx wrangler dev
```

`http://localhost:8787` 에서 실제 Worker 를 그대로 테스트할 수 있습니다.
(KV 도 로컬로 생성되므로 실제 데이터는 건드리지 않습니다.)
