/* 유진코 재고 서비스워커
   - HTML · API : network-first (항상 최신, 실패 시 캐시)
   - 아이콘·매니페스트 : cache-first
   - 새 버전 활성화 시 skipWaiting + clients.claim → 홈 화면 바로가기도 즉시 갱신 */
const VERSION = "2026-11-11-cf1";
const CACHE = "yujinco-" + VERSION;
const CORE = ["/", "/index.html", "/manifest.json", "/icons/icon-192.png", "/icons/icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    await Promise.all(CORE.map((u) => c.add(new Request(u, { cache: "reload" })).catch(() => {})));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  const isApi = url.pathname.startsWith("/api/");
  const isDoc = req.mode === "navigate" || /\.html?$/.test(url.pathname);

  if (isApi || isDoc) {
    e.respondWith((async () => {
      try {
        const fresh = await fetch(new Request(req, { cache: "no-store" }));
        if (fresh && fresh.ok && !isApi) {
          const c = await caches.open(CACHE);
          c.put(req, fresh.clone()).catch(() => {});
        }
        if (fresh && fresh.ok && isApi) {
          const c = await caches.open(CACHE);
          c.put(req, fresh.clone()).catch(() => {});
        }
        return fresh;
      } catch (err) {
        const c = await caches.open(CACHE);
        const hit = await c.match(req);
        if (hit) return hit;
        if (isDoc) {
          const shell = await c.match("/index.html");
          if (shell) return shell;
        }
        return new Response(
          isApi ? JSON.stringify({ updated: "", rows: [], offline: true })
                : "<h1>오프라인</h1><p>연결 후 다시 열어 주세요.</p>",
          { status: 503, headers: { "content-type": isApi ? "application/json" : "text/html; charset=utf-8" } }
        );
      }
    })());
    return;
  }

  e.respondWith((async () => {
    const c = await caches.open(CACHE);
    const hit = await c.match(req);
    if (hit) return hit;
    const res = await fetch(req);
    if (res && res.ok) c.put(req, res.clone()).catch(() => {});
    return res;
  })());
});

self.addEventListener("message", (e) => {
  if (e.data === "skip-waiting") self.skipWaiting();
});
