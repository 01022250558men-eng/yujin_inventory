/* 유진코 재고 — Cloudflare Worker (단일 엔트리)
   ─ 화면(정적 자산) : public/  →  env.ASSETS
   ─ 재고 읽기(GET)   : /api/inventory  →  KV (binding: INV)
   ─ 재고 쓰기(POST)  : /api/upload     →  x-admin-key == env.ADMIN_KEY 일 때만
   저장소가 비어 있으면 배포 시점 seed 를 내려준다. */
import seed from "./seed.mjs";

const KV_KEY = "inventory.json";
const MAX_BODY = 5 * 1024 * 1024; // 5MB (기존 업로드 한도 유지)
const MAX_ROWS = 20000;

const JSON_HEAD = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store, no-cache, must-revalidate, max-age=0",
  "access-control-allow-origin": "*",
};

function json(obj, status = 200, extra) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: Object.assign({}, JSON_HEAD, extra || {}),
  });
}

/* 길이·내용 비교를 타이밍에 덜 노출 */
function safeEq(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

function num(v) {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return isFinite(n) ? n : null;
}

function kstStamp(d) {
  const k = new Date(d.getTime() + 9 * 3600 * 1000);
  const p = (n) => String(n).padStart(2, "0");
  return k.getUTCFullYear() + "-" + p(k.getUTCMonth() + 1) + "-" + p(k.getUTCDate()) +
         " " + p(k.getUTCHours()) + ":" + p(k.getUTCMinutes());
}

/* ── 읽기 ── */
async function readInventory(env) {
  let saved = null;
  if (env.INV) {
    try {
      saved = await env.INV.get(KV_KEY, "json");
    } catch (e) {
      saved = null;
    }
  }
  const live = saved && Array.isArray(saved.rows) && saved.rows.length > 0;
  const src = live ? saved : seed;
  return json({
    updated: src.updated || "",
    savedAt: src.savedAt || "",
    source: live ? "live" : "seed",
    count: src.rows.length,
    rows: src.rows,
  });
}

/* ── 쓰기 ── */
async function uploadInventory(request, env) {
  const secret = env.ADMIN_KEY || "";
  if (!secret) return json({ ok: false, error: "서버에 ADMIN_KEY 시크릿이 없습니다." }, 500);

  const given = request.headers.get("x-admin-key") || "";
  if (!safeEq(given, secret)) return json({ ok: false, error: "관리자 키가 맞지 않습니다." }, 401);

  if (!env.INV) return json({ ok: false, error: "KV 바인딩(INV)이 없습니다. wrangler.toml 을 확인하세요." }, 500);

  const len = Number(request.headers.get("content-length") || 0);
  if (len > MAX_BODY) return json({ ok: false, error: "파일이 너무 큽니다 (5MB 초과)." }, 413);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ ok: false, error: "JSON 본문을 읽지 못했습니다." }, 400);
  }

  const raw = body && Array.isArray(body.rows) ? body.rows : null;
  if (!raw) return json({ ok: false, error: "rows 배열이 없습니다." }, 400);
  if (raw.length < 10) return json({ ok: false, error: "행이 너무 적습니다 (" + raw.length + "행)" }, 400);
  if (raw.length > MAX_ROWS) return json({ ok: false, error: "행이 너무 많습니다 (" + raw.length + "행)" }, 400);

  const rows = [];
  for (const r of raw) {
    if (!Array.isArray(r) || r.length < 3) continue;
    const code = String(r[0] == null ? "" : r[0]).trim();
    const name = String(r[1] == null ? "" : r[1]).trim();
    if (!code && !name) continue;
    const q = num(r[2]);
    rows.push([code, name, q === null ? 0 : q, num(r[3]), num(r[4]), r[5] ? String(r[5]).trim() : "미분류"]);
  }
  if (rows.length < 10) return json({ ok: false, error: "유효한 행이 10개 미만입니다." }, 400);

  let qty = 0, amt = 0;
  for (const r of rows) { qty += r[2] || 0; amt += r[4] || 0; }

  let prev = null;
  try { prev = await env.INV.get(KV_KEY, "json"); } catch { prev = null; }

  const now = new Date();
  const payload = {
    updated: kstStamp(now),
    savedAt: now.toISOString(),
    note: body.note ? String(body.note).slice(0, 200) : "",
    prevUpdated: (prev && prev.updated) || "",
    rows,
  };

  try {
    await env.INV.put(KV_KEY, JSON.stringify(payload));
  } catch (e) {
    return json({ ok: false, error: "KV 저장 실패: " + (e && e.message ? e.message : "unknown") }, 500);
  }

  return json({ ok: true, updated: payload.updated, count: rows.length, qty, amt: Math.round(amt) });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p = url.pathname;

    if (p === "/api/inventory" || p === "/api/inventory/") {
      if (request.method !== "GET" && request.method !== "HEAD") return json({ ok: false, error: "GET only" }, 405);
      return readInventory(env);
    }
    if (p === "/api/upload" || p === "/api/upload/") {
      if (request.method === "OPTIONS") {
        return new Response(null, {
          status: 204,
          headers: {
            "access-control-allow-origin": "*",
            "access-control-allow-headers": "content-type,x-admin-key",
            "access-control-allow-methods": "POST,OPTIONS",
            "access-control-max-age": "86400",
          },
        });
      }
      if (request.method !== "POST") return json({ ok: false, error: "POST only" }, 405);
      return uploadInventory(request, env);
    }
    if (p === "/admin" || p === "/admin/") {
      const target = new Request(new URL("/admin.html", url).toString(), request);
      return env.ASSETS.fetch(target);
    }
    if (p === "/health") return json({ ok: true, kv: !!env.INV, secret: !!env.ADMIN_KEY });

    return env.ASSETS.fetch(request);
  },
};
